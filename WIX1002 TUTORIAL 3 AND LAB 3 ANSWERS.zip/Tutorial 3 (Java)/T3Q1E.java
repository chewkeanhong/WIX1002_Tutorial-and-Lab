package t3q1e;

import java.util.Scanner;

public class T3Q1E {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter day number from 0 - 6 : ");
        int dayNumber = input.nextInt();
        
        switch (dayNumber){
            case 0 -> System.out.println("Sunday");
            case 1 -> System.out.println("Monday");
            case 2 -> System.out.println("Tuesday");
            case 3 -> System.out.println("Wednesday");
            case 4 -> System.out.println("Thursday");   
            case 5 -> System.out.println("Friday");
            case 6 -> System.out.println("Saturday");
            default -> System.out.println("Please enter day number in the range 0 to 6.");
        }

        
    }
    
}
