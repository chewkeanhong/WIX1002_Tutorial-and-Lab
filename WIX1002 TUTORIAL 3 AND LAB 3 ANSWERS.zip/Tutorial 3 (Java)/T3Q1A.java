package t3q1a;

public class T3Q1A {
    public static void main(String[] args) {
    if (3 * 8 == 27)
        System.out.println("3 x 8 equals 27");
    else
        System.out.println("3 x 8 does not equal 27");

    }
    
}
