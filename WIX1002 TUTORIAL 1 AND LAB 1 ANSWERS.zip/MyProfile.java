package l1q2;

public class MyProfile {
    public static void main(String[] args) {
        System.out.println("==========================Personal Profile===============================");
        System.out.println("Full Name: Chew Kean Hong");
        System.out.println("Matric Number: 25006697/1");
        System.out.println("Address: 306-2-11 Taman Jelutong, Jelutong 11600 Georgetown Pulau Pinang");
        System.out.println("Email: 25006697@siswa.um.edu.my");
        System.out.println("Contact:016-4323957");
        System.out.println("Programme: Bachelor of Computer Science (Artificial Intelligence)");
        System.out.println("Faculty: Faculty of Computer Science and Information Technology");
        System.out.println("University: University of Malaya");
        System.out.println("========================================================================");
    }
}