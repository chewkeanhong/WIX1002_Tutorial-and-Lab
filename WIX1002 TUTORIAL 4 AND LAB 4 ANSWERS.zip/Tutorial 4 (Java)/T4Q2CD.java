package t4q2cd;

public class T4Q2CD {
    public static void main(String[] args) {
        // Q2c
        for (int x = 1, y = 20; x < y; x++, y -= 2)
            System.out.println(x + " " + y);
        System.out.println();

        // Q2d
        int i = 1;
        while (i < 10) {
            i++;
            if (i == 10)
                System.out.println("Program End");
        }
    }
}
