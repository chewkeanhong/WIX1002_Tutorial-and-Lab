package t4q1c;

import java.util.Random;
public class T4Q1C {
    public static void main(String[] args) {
        Random random = new Random();
        for(int row = 0; row < 4; row++){
            System.out.println();
            for(int column = 0; column < 5; column++){
                int randomNumber = random.nextInt(101);
                System.out.printf("%-3s", randomNumber);
    }
}
    }
    
}
