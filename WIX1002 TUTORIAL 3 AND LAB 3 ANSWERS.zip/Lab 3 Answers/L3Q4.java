package l3q4;

import java.util.Random;

public class L3Q4{
    public static void main(String[] args){
        Random randomNum = new Random();
        
        int player1Roll1 = randomNum.nextInt(6)+1;
        System.out.println("First roll of player 1: " + player1Roll1);
        int player1Roll2 = randomNum.nextInt(6)+1;
        System.out.println("Second roll of player 1: " + + player1Roll2);
        int player1Score = player1Roll1 + player1Roll2;
        
        int player2Roll1 = randomNum.nextInt(6)+1;
        System.out.println("First roll of player 2: " + player2Roll1);
        int player2Roll2 = randomNum.nextInt(6)+1;
        System.out.println("Second roll of player 2: " + + player2Roll2);
        int player2Score = player2Roll1 + player2Roll2;
        
        System.out.println("Player 1 Score: "+ player1Score);
        System.out.println("Player 2 Score: "+ player2Score);
        
        if (player1Score > player2Score)
            System.out.println("Player 1 wins.");
        else if(player2Score > player1Score)
            System.out.println("Player 2 wins.");
        else
            System.out.println("Tie.");
       
    }
}