package t3q5;

import java.util.Scanner;

public class T3Q5 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a year: ");
        int year = input.nextInt();
        
        if (year < 1000 || year > 9999)
            System.out.println("Please enter a proper 4 digits year. ");
        else if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
            System.out.println("It is a Leap year.");
        else
            System.out.println("It is not a Leap year.");
    }
}
