package t4q1a;

public class T4Q1A {
    public static void main(String[] args) {
       int n = 1;
       while (Math.pow(n, 3) < 2000) {
           n++;
       }
       System.out.println("The largest integer n so that n^3 < 2000 is " + (n-1));

    }
}
