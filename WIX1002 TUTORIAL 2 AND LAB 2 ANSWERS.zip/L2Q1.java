package l2q1;

import java.util.Scanner;

public class L2Q1 {
    public static void main(String[] args) {
    Scanner input = new Scanner (System.in);
    System.out.print ("Enter the temperature in Fahrenheit: ");
    double fahrenheit = input.nextDouble();
    double celcius = (fahrenheit - 32) / 1.8;
    System.out.printf("Temperature in Celcius: %.2f degree Celcius%n",celcius);
    }
}
