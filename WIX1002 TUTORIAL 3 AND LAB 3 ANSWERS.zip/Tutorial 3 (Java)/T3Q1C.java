package t3q1c;

public class T3Q1C {
    public static void main(String[] args) {
       char character = 'P';  // example of character
       
       if (Character.isUpperCase(character)) 
           System.out.println(character + " is a capital letter.");
       else 
           System.out.println(character + " is not a capital letter.");

    }
    
}