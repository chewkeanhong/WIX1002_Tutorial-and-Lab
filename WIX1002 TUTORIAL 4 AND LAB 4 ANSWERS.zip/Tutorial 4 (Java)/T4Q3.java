package t4q3;

public class T4Q3 {
    public static void main(String[] args) {
        int f1 = 1;
        int f2 = 1;
        System.out.print(f1 + ", " + f2 + ", ");
        int ct = 2;
        while (ct < 10){
            int f_next = f1 + f2;
            System.out.print(f_next + ", ");
            f1 = f2;
            f2 = f_next; 
            ct++;
        }
        System.out.println(f1 + f2);
    }
    
}
