package l3q3;

import java.util.Scanner;
public class L3Q3 {
    public static void main(String[] args){
        Scanner input = new Scanner (System.in);
        System.out.print("Enter the sales volume: ");
        int salesVolume = input.nextInt();
        
        double commission;
        
        if (salesVolume <= 100)
            commission = 0.05;
        else if (salesVolume > 100 && salesVolume <= 500)
            commission = 0.075;
        else if (salesVolume > 500 && salesVolume <= 1000)
            commission = 0.1;
        else
            commission = 0.125;
        
        double totalCommission = salesVolume * commission;
        System.out.printf("%.2f%n", totalCommission);
    }
}