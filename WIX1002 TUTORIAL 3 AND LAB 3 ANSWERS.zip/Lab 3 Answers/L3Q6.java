package l3q6;

import java.util.Scanner;


public class L3Q6 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
        System.out.print("Radius : ");
        double radius = input.nextDouble();
        
        System.out.print("x : ");
        int x = input.nextInt();
        System.out.print("y : ");
        int y = input.nextInt();
        
        double xCoordinate = Math.pow((x-0),2);
        double yCoordinate = Math.pow ((y-0),2);
        double distance = Math.sqrt(xCoordinate + yCoordinate);
        
        System.out.printf("Distance : %.2f%n", distance);
        
        if (distance < radius)
            System.out.println("The point is inside the circle.");
        else if (distance > radius)
            System.out.println("The point is outside the circle.");
        else
            System.out.println("The point is on the circle.");
        
        
    }
}