package t4q2ab;

public class T4Q2AB {
    public static void main(String[] args) {
        int sum =0;
        //Q2a
        // correct answer
        for (int x = 10; x > 0; x--)
            sum += x;
        System.out.println(sum);
        System.out.println();
        
        //Q2b
        // correct answer
        int x = 0;
        int y = 0;
        do {
            x += 2;
            y += x;
            System.out.println(x + " and " + y);
        } while (x < 100);
        System.out.println();
    }
    
}
