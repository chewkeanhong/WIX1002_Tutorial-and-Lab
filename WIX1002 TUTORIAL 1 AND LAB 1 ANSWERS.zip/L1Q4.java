package l1q4;

public class L1Q4 {
    public static void main(String[] args) {
        String [] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun"};
        int [] sales = {2500, 1600, 2000, 2700, 3200, 800};
        
        System.out.println("==== Total Sales of Product A (2016) ====");
        for (int i = 0; i < months.length; i++) {
            System.out.printf("%-10s :", months [i]);
            for (int j = 0; j < sales[i] / 100; j++) {
                System.out.print("*");
               
            }
            System.out.printf("{%d}%n", sales[i]);
        }
    }
}