package l2q3;

import java.util.Random;

public class L2Q3 {
    public static void main(String[] args){
        Random rd = new Random();
        
        int num1 = rd.nextInt(41) + 10;
        int num2 = rd.nextInt(41) +10;
        int num3 = rd.nextInt(41) +10;
        
        int sum = num1+num2+num3;
        double average = (double) sum/3;
        
        System.out.printf("Numbers: %d, %d, %d%n",num1,num2,num3);
        System.out.printf("Sum = %d%n", sum);
        System.out.printf("Average: %.2f%n", average);
    }
}