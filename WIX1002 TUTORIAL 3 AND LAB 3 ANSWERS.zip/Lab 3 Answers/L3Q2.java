package l3q2;

import java.util.Random;

public class L3Q2 {
    public static void main(String[] args) {
        Random randomInt = new Random();
        int randomNum = randomInt.nextInt(6);
        
        String naming = "";
        switch(randomNum) {
            case 0 -> naming = "zero";
            case 1 -> naming = "one";
            case 2 -> naming = "two";
            case 3 -> naming = "three";
            case 4 -> naming = "four";
            case 5 -> naming = "five";
        }
       
        System.out.println(randomNum +" is " + naming +"." );
        
        
    }
}