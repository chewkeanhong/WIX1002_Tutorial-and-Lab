package t3q4;

import java.util.Scanner;

public class T3Q4 {
    public static void main(String[] args){
        Scanner input = new Scanner (System.in);
        System.out.print("Enter the first integer: ");
        int a = input.nextInt();
        System.out.print("Enter the second integer: ");
        int b = input.nextInt();
        System.out.print("Enter the third integer: ");
        int c = input.nextInt();
        
        int biggestNum;
        
        if (a >= b && a>=c)
            biggestNum = a;
        
        else if (b >= a && b >= c)
            biggestNum = b;
        else
            biggestNum = c;
        
        System.out.println("Biggest number among three given integers : " + biggestNum);
    }
}
