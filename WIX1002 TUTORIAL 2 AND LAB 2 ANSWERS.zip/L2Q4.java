package l2q4;

import java.util.Scanner;

public class L2Q4 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter the number of seconds: ");
        int input = sc.nextInt();
        
        int hours = input/3600;
        int minutes = (input%3600)/60;
        int seconds = input%60;
        
        System.out.printf("%d seconds is %d hours, %d minutes and %d seconds%n", input,hours,minutes,seconds);
    }
}