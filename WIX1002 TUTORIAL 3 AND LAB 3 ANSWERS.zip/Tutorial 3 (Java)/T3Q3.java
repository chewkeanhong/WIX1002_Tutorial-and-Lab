package t3q3;

public class T3Q3 {
    public static void main(String[] args) {
       int x =9;
       int y = 10;
       
       //Q3a
       if (x < 10) 
           if (y > 10) 
               System.out.println("*****"); 
           else 
               System.out.println("#####"); 
               System.out.println("$$$$$");
               
               System.out.println();
               
       //Q3b        
       if (x < 10) { 
           if (y < 10) 
               System.out.println("*****"); 
           else{ 
               System.out.println("#####"); 
               System.out.println("$$$$$"); 
           }}
               System.out.println();
       
       //Q3c
       if (x < 10) { 
           if (y < 10) 
               System.out.println("*****"); 
               System.out.println("#####"); 
           }else { 
           System.out.println("$$$$$"); 
       }
           System.out.println();
           
       //Q3d
       if (x > 10) { 
           if (y > 10) { 
               System.out.println("*****"); 
               System.out.println("#####"); } 
           else 
               System.out.println("$$$$$"); 
       }
       

      

  


    }
    
}
