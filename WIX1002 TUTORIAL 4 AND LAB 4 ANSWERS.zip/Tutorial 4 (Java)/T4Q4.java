package t4q4;

public class T4Q4 {
    public static void main(String[] args) {
        String string = "Hello World";
        String reversedStr = "";
        for(int i = string.length()-1; i >= 0; i--){
            reversedStr += string.charAt(i);
        }
        System.out.println("Reversed String : " + reversedStr);
    }
    
}
