package l2q5;

import java.util.Random;

public class L2Q5 {
    public static void main(String[] args) {
        Random random = new Random();
        int randomVal = random.nextInt(10001);
      
        
        int sum = 0, temp = randomVal;
        while (temp > 0){
            sum += temp % 10;
            temp /= 10;
        } 
        
        System.out.printf("Number: %d%n", randomVal);
        System.out.printf("Sum of all digits: %d%n ", sum);
    }
}