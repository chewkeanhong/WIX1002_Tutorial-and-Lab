package t3q1d;

public class T3Q1D {

    
    public static void main(String[] args) {
       String str1 = "Computer";
       String str2 = "Science";
       int compareString = str1.compareToIgnoreCase(str2);
       if (compareString < 0)
           System.out.println(str1 + ", " + str2);
       else
           System.out.println(str2 + ", " + str1);

    }
    
}
