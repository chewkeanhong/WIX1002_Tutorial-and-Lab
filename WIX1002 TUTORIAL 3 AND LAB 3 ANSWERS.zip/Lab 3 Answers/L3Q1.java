package l3q1;

import java.util.Scanner;
public class L3Q1 {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter two integer number: ");
    int num1 = input.nextInt();
    int num2 = input.nextInt();
    System.out.print("Enter the operand: ");
    char operator = input.next().charAt(0);
    
    int result = 0;
    boolean valid = true;
    
    switch(operator){
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '*': 
            result = num1 * num2;
            break;
        case '/':
            result = num1 / num2;
            break;
        case '%':
            result = num1 % num2;
            break;
        default:{
            System.out.println("It is an invalid operator.");
            valid = false;
        }
    }
   
    if (valid == true)
        System.out.printf("%d %c %d = %d%n",num1, operator, num2, result);
    }
}
