package l4q2;

import java.util.Scanner;

public class L4Q2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter integer n : ");
        int n = input.nextInt();
        int num = 0;
        int total = 0;
        for(int i = 1; i <= n; i++){
            num += i;
            total += num;
        }
        
        System.out.println("Total : " + total);
    }
    
}
