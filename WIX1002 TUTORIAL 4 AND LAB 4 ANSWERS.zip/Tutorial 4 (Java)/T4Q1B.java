package t4q1b;

public class T4Q1B {
    public static void main(String[] args) {
       for(int i = 1; i <= 12; i++){
           System.out.println(i + "^2 = " + i*i);
       }
    }
    
}
