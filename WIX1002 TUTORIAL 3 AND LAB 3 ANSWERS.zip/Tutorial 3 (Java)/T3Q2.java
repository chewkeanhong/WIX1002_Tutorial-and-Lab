package t3q2;


public class T3Q2 {

    
    public static void main(String[] args) {
        int num1 = 23;
        int num2 = 23;
        //Q2a
        //Correct answer
        if (num1 == num2)
            System.out.println("Number 1 is equal to number 2.");
        
        System.out.println();
        
        int x = 10;
        int y = 7;
        int z = 5;
        //Q2b
        //Correct answer
        if (x > y && x > z)
            System.out.println("x is the largest number");
        
        System.out.println();
        
        //Q2c
        //Correct answer
        String s1, s2;
        s1 = "Science";//Example
        s2 = "Science";//Example
        if (s1.equals(s2))
            System.out.println("They are equal strings.");
        else
            System.out.println("They are not equal strings.");
        
        System.out.println();
        
        
        //Q2d
        // correct answer
        if (x>0 || y>0)
        System.out.println("Either x or y is positive");




    }
    
}
